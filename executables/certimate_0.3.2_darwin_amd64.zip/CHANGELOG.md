A full changelog of past releases is available on [GitHub Releases](https://github.com/usual2970/certimate/releases) page.
